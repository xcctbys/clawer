select * from user;
--select * from host;
select * from user;
select * -- foo;
from foo;